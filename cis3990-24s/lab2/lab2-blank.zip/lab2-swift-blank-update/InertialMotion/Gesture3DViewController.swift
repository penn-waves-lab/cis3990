//
//  Gesture3DViewController.swift
//  InertialMotion
//
//  Created by Justin Anderson on 3/15/17.
//  Copyright © 2017 MIT. All rights reserved.
//

import UIKit
import CoreMotion
import GLKit

private func GLKQuaternionFromCMQuaternion(_ quat: CMQuaternion) -> GLKQuaternion {
    return GLKQuaternionMake(Float(quat.x), Float(quat.y), Float(quat.z), Float(quat.w))
}

private func GLKVector3FromCMAcceleration(_ acceleration: CMAcceleration) -> GLKVector3 {
    return GLKVector3Make(Float(acceleration.x), Float(acceleration.y), Float(acceleration.z))
}

class Gesture3DViewController: RibbonViewController, GestureProcessorDelegate {

    @IBOutlet weak var recognizedLabel: UILabel?
    @IBOutlet weak var scribbleView: ScribbleView?
    
    var touchCount: Int = 0
    var motionManager: CMMotionManager = CMMotionManager()
    var samples: [Sample3D] = []
    var position: GLKVector3 = GLKVector3()
    var velocity: GLKVector3 = GLKVector3()

    override func viewDidLoad() {
        super.viewDidLoad()

        motionManager.deviceMotionUpdateInterval = 1e-2
        
        motionManager.startDeviceMotionUpdates(
            using: .xArbitraryCorrectedZVertical,
            to: OperationQueue.main) { [weak self] (motion, error) in
                self?.accumulateMotion(motion)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        becomeFirstResponder()
        samples.removeAll()
        
        let delegate = UIApplication.shared.delegate as! AppDelegate
        delegate.gestureProcessor.delegate = self

        super.viewDidAppear(animated)
    }
    
    func updateTouches(_ event: UIEvent?) {
        let touches = event?.allTouches?.filter({
            switch $0.phase {
            case .began, .moved, .stationary:
                return true
            default:
                return false
            }
        })
        touchCount = touches?.count ?? 0
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        updateTouches(event)
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        updateTouches(event)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        updateTouches(event)
    }
    
    func accumulateMotion(_ motion: CMDeviceMotion?) {
        guard let motion = motion else {
            return
        }
        
        let dt = motionManager.deviceMotionUpdateInterval
        let attitude = GLKQuaternionFromCMQuaternion(motion.attitude.quaternion)
        let userAcceleration = GLKVector3FromCMAcceleration(motion.userAcceleration)
        
        // -- TASK 2A --
        var acceleration: GLKVector3 = userAcceleration
        // rotate acceleration from instantaneous coordinates into persistent coordinates

        // -- TASK 2B --
        // integrate acceleration into velocity and velocity into position
        
        // -- TASK 2C --
        // apply your choice of braking to velocity and position to stabilize the integration loop
        
        // add the new data to the log
        
        appendPoint(position, attitude: attitude)
    }
    
    func appendPoint(_ point: GLKVector3, attitude: GLKQuaternion) {
        let draw: Bool = touchCount > 0
        if draw {
            let s = Sample3D(location: point,
                             attitude: attitude,
                             t: Date.timeIntervalSinceReferenceDate)
            samples.append(s)
        } else if (samples.count > 0) {
            let delegate = UIApplication.shared.delegate as! AppDelegate
            let samples2D = delegate.gestureProcessor.processGesture3D(
                samples: samples, minSize: 0.01)
            
            // scribbleView shows the rescaled 2-D samples, mapped from 3-D samples
            scribbleView?.clear()
            for sample2D in samples2D {
                // scale to fit view
                let scale = Double((scribbleView?.frame.height)!)
                let point = CGPoint(x: sample2D.x * scale,
                                    y: sample2D.y * scale)
                scribbleView?.add(point: point)
            }
            
            samples.removeAll()
        }
        super.appendPoint(point, attitude: attitude, draw: draw)
    }
    
    func gestureProcessor(_ gestureProcessor: GestureProcessor, didRecognizeGesture label: String) {
        recognizedLabel?.text = recognizedLabel?.text?.appending(label)
    }
}
